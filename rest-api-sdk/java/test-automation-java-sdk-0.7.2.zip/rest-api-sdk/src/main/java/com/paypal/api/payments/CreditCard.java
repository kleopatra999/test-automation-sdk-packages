package com.paypal.api.payments;

import com.paypal.core.rest.JSONFormatter;
import com.paypal.api.payments.Address;
import com.paypal.api.payments.Links;
import java.util.List;
import java.util.Map;

public class CreditCard  {

	/**
	 * ID of the credit card being saved for later use.
	 */
	private String id;
	
	/**
	 * Card number.
	 */
	private String number;
	
	/**
	 * Type of the Card (eg. Visa, Mastercard, etc.).
	 */
	private String type;
	
	/**
	 * card expiry month with value 1 - 12.
	 */
	private int expireMonth;
	
	/**
	 * 4 digit card expiry year
	 */
	private int expireYear;
	
	/**
	 * Card validation code. Only supported when making a Payment but not when saving a credit card for future use.
	 */
	private String cvv2;
	
	/**
	 * Card holder's first name.
	 */
	private String firstName;
	
	/**
	 * Card holder's last name.
	 */
	private String lastName;
	
	/**
	 * Billing Address associated with this card.
	 */
	private Address billingAddress;
	
	/**
	 * A unique identifier of the payer generated and provided by the facilitator. This is required when creating or using a tokenized funding instrument.
	 */
	private String payerId;
	
	/**
	 * State of the funding instrument.
	 */
	private String state;
	
	/**
	 * Date/Time until this resource can be used fund a payment.
	 */
	private String validUntil;
	
	/**
	 * 
	 */
	private List<Links> links;
	
	/**
	 * Default Constructor
	 */
	public CreditCard() {
	}

	/**
	 * Parameterized Constructor
	 */
	public CreditCard(String number, String type, int expireMonth, int expireYear) {
		this.number = number;
		this.type = type;
		this.expireMonth = expireMonth;
		this.expireYear = expireYear;
	}
	

	/**
	 * Setter for id
	 */
	public CreditCard setId(String id) {
		this.id = id;
		return this;
	}
	
	/**
	 * Getter for id
	 */
	public String getId() {
		return this.id;
	}


	/**
	 * Setter for number
	 */
	public CreditCard setNumber(String number) {
		this.number = number;
		return this;
	}
	
	/**
	 * Getter for number
	 */
	public String getNumber() {
		return this.number;
	}


	/**
	 * Setter for type
	 */
	public CreditCard setType(String type) {
		this.type = type;
		return this;
	}
	
	/**
	 * Getter for type
	 */
	public String getType() {
		return this.type;
	}


	/**
	 * Setter for expireMonth
	 */
	public CreditCard setExpireMonth(int expireMonth) {
		this.expireMonth = expireMonth;
		return this;
	}
	
	/**
	 * Getter for expireMonth
	 */
	public int getExpireMonth() {
		return this.expireMonth;
	}


	/**
	 * Setter for expireYear
	 */
	public CreditCard setExpireYear(int expireYear) {
		this.expireYear = expireYear;
		return this;
	}
	
	/**
	 * Getter for expireYear
	 */
	public int getExpireYear() {
		return this.expireYear;
	}


	/**
	 * Setter for cvv2
	 */
	public CreditCard setCvv2(String cvv2) {
		this.cvv2 = cvv2;
		return this;
	}
	
	/**
	 * Getter for cvv2
	 */
	public String getCvv2() {
		return this.cvv2;
	}


	/**
	 * Setter for firstName
	 */
	public CreditCard setFirstName(String firstName) {
		this.firstName = firstName;
		return this;
	}
	
	/**
	 * Getter for firstName
	 */
	public String getFirstName() {
		return this.firstName;
	}


	/**
	 * Setter for lastName
	 */
	public CreditCard setLastName(String lastName) {
		this.lastName = lastName;
		return this;
	}
	
	/**
	 * Getter for lastName
	 */
	public String getLastName() {
		return this.lastName;
	}


	/**
	 * Setter for billingAddress
	 */
	public CreditCard setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
		return this;
	}
	
	/**
	 * Getter for billingAddress
	 */
	public Address getBillingAddress() {
		return this.billingAddress;
	}


	/**
	 * Setter for payerId
	 */
	public CreditCard setPayerId(String payerId) {
		this.payerId = payerId;
		return this;
	}
	
	/**
	 * Getter for payerId
	 */
	public String getPayerId() {
		return this.payerId;
	}


	/**
	 * Setter for state
	 */
	public CreditCard setState(String state) {
		this.state = state;
		return this;
	}
	
	/**
	 * Getter for state
	 */
	public String getState() {
		return this.state;
	}


	/**
	 * Setter for validUntil
	 */
	public CreditCard setValidUntil(String validUntil) {
		this.validUntil = validUntil;
		return this;
	}
	
	/**
	 * Getter for validUntil
	 */
	public String getValidUntil() {
		return this.validUntil;
	}


	/**
	 * Setter for links
	 */
	public CreditCard setLinks(List<Links> links) {
		this.links = links;
		return this;
	}
	
	/**
	 * Getter for links
	 */
	public List<Links> getLinks() {
		return this.links;
	}

	/**
	 * Returns a JSON string corresponding to object state
	 * 
	 * @return JSON representation
	 */
	public String toJSON() {
		return JSONFormatter.toJSON(this);
	}

	@Override
	public String toString() {
		return toJSON();
	}
}