Message to display in the changelog
Update stubs for java 94 release
Message to display in the changelog
Update stubs for java 94 release
Message to display in the changelog
Update stubs for java 94 release

 
V0.7.1 (July 31, 2013)
-----------------------
   * Added support for Reauthorization

V0.7.0 (May 30, 2013)
-----------------------
   * Added support for Auth and Capture APIs
   * Types Modified to match the API Spec

V0.6.0 (April 26, 2013)
-----------------------
   * Added dynamic configuration support for API calls

V0.5.2 (March 07, 2013)
-----------------------
   * Initial Release


