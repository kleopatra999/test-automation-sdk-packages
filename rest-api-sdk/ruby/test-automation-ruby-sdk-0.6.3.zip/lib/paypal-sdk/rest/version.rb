module PayPal
  module SDK
    module REST
      VERSION = "0.6.3"
    end
  end
end
