module PayPal
  module SDK
    module REST
      VERSION = "0.6.2"
    end
  end
end
