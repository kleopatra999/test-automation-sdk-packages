<?php
namespace PayPal\Api;

use PayPal\Rest\ApiContext;
use PayPal\Common\PPModel;

class BankAccountsList extends PPModel {
	/**
	 * A list of bank account resources
	 *
	 * @array
	 * @param PayPal\Api\BankAccount $bank-accounts
	 */
	public function setBankAccounts($bank_accounts) {
		$this->{"bank-accounts"} = $bank_accounts;
		return $this;
	}

	/**
	 * A list of bank account resources
	 *
	 * @return PayPal\Api\BankAccount
	 */
	public function getBankAccounts() {
		return $this->{"bank-accounts"};
	}

	/**
	 * A list of bank account resources
	 *
	 * @array
	 * @param PayPal\Api\BankAccount $bank-accounts
	 * @deprecated. Instead use setBankAccounts
	 */
	public function setBank_accounts($bank_accounts) {
		$this->{"bank-accounts"} = $bank_accounts;
		return $this;
	}
	/**
	 * A list of bank account resources
	 *
	 * @return PayPal\Api\BankAccount
	 * @deprecated. Instead use getBankAccounts
	 */
	public function getBank_accounts() {
		return $this->{"bank-accounts"};
	}

	/**
	 * Number of items returned in each range of results. Note that the last results range could have fewer items than the requested number of items.
	 *
	 * @param integer $count
	 */
	public function setCount($count) {
		$this->count = $count;
		return $this;
	}

	/**
	 * Number of items returned in each range of results. Note that the last results range could have fewer items than the requested number of items.
	 *
	 * @return integer
	 */
	public function getCount() {
		return $this->count;
	}


	/**
	 * Identifier of the next element to get the next range of results.
	 *
	 * @param string $next_id
	 */
	public function setNextId($next_id) {
		$this->next_id = $next_id;
		return $this;
	}

	/**
	 * Identifier of the next element to get the next range of results.
	 *
	 * @return string
	 */
	public function getNextId() {
		return $this->next_id;
	}

	/**
	 * Identifier of the next element to get the next range of results.
	 *
	 * @param string $next_id
	 * @deprecated. Instead use setNextId
	 */
	public function setNext_id($next_id) {
		$this->next_id = $next_id;
		return $this;
	}
	/**
	 * Identifier of the next element to get the next range of results.
	 *
	 * @return string
	 * @deprecated. Instead use getNextId
	 */
	public function getNext_id() {
		return $this->next_id;
	}

}
