<?php
namespace PayPal\Test\Common;
use PayPal\Common\PPModel;
class ChildClass extends SimpleClass {
	
}