CHANGELOG
=========
0.7.2  (September 18,2013)
-----------------------------
Update stubs for php 107 release

 

V0.7.1 (July 31, 2013)
-----------------------
   * Added support for Reauthorization

V0.7.0 (May 30, 2013)
-----------------------

   * Added support for Auth and Capture APIs
   * Types modified to match the API Spec
   * Updated SDK to use namespace supported core library 

V0.6.0 (April 26, 2013)
-----------------------

   * Adding support for dynamic configuration of SDK (Upgrading sdk-core-php dependency to V1.4.0)
   * Deprecating the setCredential method and changing resource class methods to take an ApiContext argument instead of a OauthTokenCredential argument.

V0.5.0 (March 07, 2013)
-----------------------

   * Initial Release
